package com.senai.anotacoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnotacoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
