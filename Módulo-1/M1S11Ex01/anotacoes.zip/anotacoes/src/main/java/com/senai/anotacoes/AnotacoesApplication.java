package com.senai.anotacoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnotacoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnotacoesApplication.class, args);
	}

}
