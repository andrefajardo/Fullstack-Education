package br.com.school.administration.schoolAdministration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolAdministrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolAdministrationApplication.class, args);
	}

}
